# 心语时光

心语时光是一个带记忆体管理、网页上传、按记忆体聊天、历史会话、角色参数和情绪日记的前后端项目。

## 本地启动

一键启动前后端：

```powershell
.\start-dev.ps1
```

脚本会启动：

- 后端：http://127.0.0.1:8000
- 前端：http://127.0.0.1:5173

也可以按下面步骤手动启动。

### 1. 后端

进入后端目录：

```powershell
cd heart-time\backend
```

安装依赖：

```powershell
python -m pip install -r requirements.txt
```

启动服务：

```powershell
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

默认情况下后端会使用 SQLite：

```text
heart-time/backend/emotion_system.db
```

启动时会自动创建当前接口需要的基础表，并写入演示所需的测试用户、角色参数和一个默认记忆体。

如果要使用 MySQL，设置环境变量 `DATABASE_URL`：

```powershell
$env:DATABASE_URL="mysql+pymysql://root:456852@localhost:3306/emotion_system?charset=utf8mb4"
python -m uvicorn main:app --host 127.0.0.1 --port 8000
```

### 2. 前端

进入前端目录：

```powershell
cd heart-time\frontend
```

安装依赖后启动：

```powershell
npm install
npm run dev -- --host 127.0.0.1
```

访问：

```text
http://127.0.0.1:5173/
```

Vite 会把 `/api` 请求代理到 `http://localhost:8000`。

## 测试账号

```text
用户名：testuser
密码：123456
```

## AI Key

真实聊天和真实向量化需要：

```text
DEEPSEEK_API_KEY
DASHSCOPE_API_KEY
```

可以参考：

```text
heart-time/backend/.env.example
```

没有配置 key 时，项目会自动进入本地演示模式：

- 后端可以直接启动
- 记忆体上传会生成本地确定性向量
- 聊天会返回本地演示回复
- 历史消息仍会写入并可恢复

配置真实 key 后，会切回真实 DeepSeek 聊天和 DashScope embedding。

## 常用验证

一键验证：

```powershell
.\verify.ps1
```

如果前后端服务已经启动，可以追加 API 闭环验证：

```powershell
.\verify.ps1 -Api
```

或分别执行前后端验证。

前端：

```powershell
cd heart-time\frontend
npm run build
npm run lint
```

后端：

```powershell
python -m py_compile heart-time\backend\config.py heart-time\backend\main.py heart-time\backend\api\memories.py heart-time\backend\api\chat_sessions.py
```

## 已接入功能

- 登录
- 管理记忆体
- 选择记忆体进入对话
- 新建/删除记忆体
- 上传 txt 或粘贴文本导入记忆体
- 按记忆体创建和筛选会话
- 发送聊天消息
- 恢复历史消息
- 查看角色参数
- 保存和查看情绪日记
