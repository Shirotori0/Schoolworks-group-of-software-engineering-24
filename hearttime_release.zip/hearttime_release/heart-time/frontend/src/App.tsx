import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { FormEvent } from 'react'
import './App.css'

type Page = 'login' | 'home' | 'chat' | 'memory'
type MemoryManageView = 'list' | 'detail' | 'create'
type MemoryDetailTab = 'import' | 'roles' | 'diary'
type Sender = 'user' | 'ai' | 'system'

type AuthState = {
  token: string
  userId: string
}

type LoginResponse = {
  token: string
  user_id: string
}

type Message = {
  id: string
  sender: Sender
  content: string
}

type MemoryBody = {
  id: string
  userId: string
  name: string
  summary: string
  source: string
  vectorPath: string
  createdAt: string
  updatedAt: string
  importStatus: 'not_imported' | 'imported' | 'failed'
}

type MemoryResponse = {
  memory_id: string
  user_id: string
  name: string
  summary: string
  source_file_path: string
  vector_file_path: string
  import_status: string
  created_at: string
  updated_at: string
}

type UploadMemoryResponse = {
  memory_id: string
  file_path: string
  vector_path: string
  import_status: string
  message: string
}

type ChatSessionRecord = {
  id: string
  backendSessionId: string
  memoryId: string
  title: string
  messages: Message[]
  createdAt: string
  updatedAt: string
}

type BackendSessionItem = {
  session_id: string
  memory_id?: string | null
  title: string
  created_at: string
  updated_at: string
}

type BackendMessageItem = {
  message_id: string
  sender: Sender
  content: string
  created_at: string
}

type DiaryItem = {
  diary_id: number
  content: string
  emotion_tags?: string | null
  ai_reply?: string | null
  create_time: string
}

type RoleItem = {
  role_id: number
  role_name: string
  gentleness: number
  rationality: number
}

type Particle = {
  id: number
  x: number
  y: number
  vx: number
  vy: number
  baseVx: number
  baseVy: number
  radius: number
}

const API_BASE = '/api/v1'
const AUTH_STORAGE_KEY = 'heart-time-auth'
const DIARY_USER_ID = 1
const PARTICLE_LINK_DISTANCE = 150
const PARTICLE_LINK_DISTANCE_SQUARED = PARTICLE_LINK_DISTANCE ** 2
const PARTICLE_REPULSE_RADIUS = 200
const PARTICLE_REPULSE_RADIUS_SQUARED = PARTICLE_REPULSE_RADIUS ** 2
const PARTICLE_REPULSE_RELAX_RADIUS = 285
const PARTICLE_REPULSE_RELAX_RADIUS_SQUARED = PARTICLE_REPULSE_RELAX_RADIUS ** 2
const PARTICLE_DENSITY_AREA = 12000
const PARTICLE_MOBILE_DENSITY_AREA = 14000
const PARTICLE_LOW_COUNT = 60
const PARTICLE_MEDIUM_COUNT = 92
const PARTICLE_HIGH_COUNT = 128
const PARTICLE_PUSH_COUNT = 4
const PARTICLE_GRID_CELL_SIZE = PARTICLE_LINK_DISTANCE
const PARTICLE_DESKTOP_FRAME_MS = 1000 / 45
const PARTICLE_LOW_FRAME_MS = 1000 / 30

const INITIAL_MEMORIES: MemoryBody[] = [
  {
    id: 'memory-test',
    userId: 'user_001',
    name: '默认记忆体',
    summary: '用于快速开始对话的基础记忆体。',
    source: 'ai/data/raw/test.txt',
    vectorPath: 'ai/data/vectors/test.txt.jsonl',
    createdAt: new Date('2026-06-01T09:00:00').toISOString(),
    updatedAt: new Date('2026-06-01T09:00:00').toISOString(),
    importStatus: 'imported',
  },
  {
    id: 'memory-mesmer',
    userId: 'user_001',
    name: '小梅斯梅尔',
    summary: '围绕角色设定和故事片段展开对话。',
    source: 'ai/data/raw/Mesmer.txt',
    vectorPath: 'ai/data/vectors/Mesmer.txt.jsonl',
    createdAt: new Date('2026-06-01T10:00:00').toISOString(),
    updatedAt: new Date('2026-06-01T10:00:00').toISOString(),
    importStatus: 'imported',
  },
  {
    id: 'memory-toothfairy',
    userId: 'user_001',
    name: '牙仙',
    summary: '适合继续角色陪伴和剧情式交流。',
    source: 'ai/data/raw/牙仙.txt',
    vectorPath: '',
    createdAt: new Date('2026-06-01T11:00:00').toISOString(),
    updatedAt: new Date('2026-06-01T11:00:00').toISOString(),
    importStatus: 'not_imported',
  },
]

async function requestJson<T>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  const isFormData = options.body instanceof FormData
  const headers = new Headers(options.headers)

  if (!isFormData && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json')
  }

  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  })

  const text = await response.text()
  const body = text ? JSON.parse(text) : null

  if (!response.ok) {
    const detail = body?.error || body?.detail || body?.message
    const message =
      typeof detail === 'string'
        ? detail
        : detail
          ? JSON.stringify(detail)
          : '请求失败'
    throw new Error(message)
  }

  return body as T
}

function readStoredAuth(): AuthState | null {
  try {
    const raw = window.localStorage.getItem(AUTH_STORAGE_KEY)
    if (!raw) return null

    const parsed = JSON.parse(raw) as Partial<AuthState>
    if (typeof parsed.token === 'string' && typeof parsed.userId === 'string') {
      return {
        token: parsed.token,
        userId: parsed.userId,
      }
    }
  } catch {
    window.localStorage.removeItem(AUTH_STORAGE_KEY)
  }

  return null
}

function storeAuth(auth: AuthState) {
  window.localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(auth))
}

function clearStoredAuth() {
  window.localStorage.removeItem(AUTH_STORAGE_KEY)
}

function normalizeImportStatus(value: string): MemoryBody['importStatus'] {
  if (value === 'imported' || value === 'failed' || value === 'not_imported') {
    return value
  }

  return 'not_imported'
}

function formatImportStatus(value: MemoryBody['importStatus']) {
  if (value === 'imported') return '已导入'
  if (value === 'failed') return '导入失败'
  return '未导入'
}

function mapMemoryResponse(memory: MemoryResponse): MemoryBody {
  const now = new Date().toISOString()

  return {
    id: memory.memory_id,
    userId: memory.user_id,
    name: memory.name,
    summary: memory.summary || '暂无简介。',
    source: memory.source_file_path || '',
    vectorPath: memory.vector_file_path || '',
    importStatus: normalizeImportStatus(memory.import_status),
    createdAt: memory.created_at || now,
    updatedAt: memory.updated_at || memory.created_at || now,
  }
}

function createParticle(
  width: number,
  height: number,
  id: number,
  x?: number,
  y?: number,
): Particle {
  const speed = 2 + Math.random() * 1.4
  const angle = Math.random() * Math.PI * 2
  const vx = Math.cos(angle) * speed
  const vy = Math.sin(angle) * speed

  return {
    id,
    x: x ?? Math.random() * width,
    y: y ?? Math.random() * height,
    vx,
    vy,
    baseVx: vx,
    baseVy: vy,
    radius: 1.8 + Math.random() * 3.2,
  }
}

function isLowMotionDevice(width: number) {
  return width < 820 || (navigator.hardwareConcurrency || 4) <= 4
}

function getParticleLimit(width: number, isQuiet = false) {
  if (isQuiet) return width < 820 ? 46 : 96

  const cores = navigator.hardwareConcurrency || 4

  if (width < 820 || cores <= 4) return PARTICLE_LOW_COUNT
  if (cores <= 8) return PARTICLE_MEDIUM_COUNT

  return PARTICLE_HIGH_COUNT
}

function getParticleCount(width: number, height: number, isQuiet = false) {
  const isMobile = width < 820
  const densityArea = isQuiet
    ? PARTICLE_DENSITY_AREA * 1.9
    : isMobile
      ? PARTICLE_MOBILE_DENSITY_AREA
      : PARTICLE_DENSITY_AREA
  const densityCount = Math.round((width * height) / densityArea)
  const minimumCount = isQuiet ? (isMobile ? 14 : 28) : isMobile ? 24 : 36

  return Math.min(Math.max(densityCount, minimumCount), getParticleLimit(width, isQuiet))
}

function createParticles(width: number, height: number, count: number): Particle[] {
  return Array.from({ length: count }, (_, index) =>
    createParticle(width, height, index),
  )
}

function getCanvasDpr(width: number, isQuiet = false) {
  const maxDpr = isQuiet ? 1.15 : width < 820 ? 1.25 : 1.5

  return Math.min(window.devicePixelRatio || 1, maxDpr)
}

function getTargetFrameMs(width: number, isQuiet = false) {
  return isQuiet || isLowMotionDevice(width)
    ? PARTICLE_LOW_FRAME_MS
    : PARTICLE_DESKTOP_FRAME_MS
}

function getInitialMessages(memoryName: string): Message[] {
  return [
    {
      id: crypto.randomUUID(),
      sender: 'system',
      content: `已进入「${memoryName}」记忆体，可以开始新的对话。`,
    },
  ]
}

function formatTime(value: string) {
  const timestamp = Date.parse(value)

  if (!value || Number.isNaN(timestamp)) {
    return '未记录'
  }

  return new Intl.DateTimeFormat('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(timestamp))
}

function makeSessionTitle(content: string) {
  const plain = content.trim().replace(/\s+/g, ' ')
  return plain.length > 18 ? `${plain.slice(0, 18)}...` : plain || '新的对话'
}

function HomeParticleField({ quiet = false }: { quiet?: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const context = canvas?.getContext('2d')

    if (!canvas || !context) return

    let width = 0
    let height = 0
    let animationFrame = 0
    let lastFrameTime = performance.now()
    let targetFrameMs = PARTICLE_DESKTOP_FRAME_MS
    let nextParticleId = 0
    let gridColumns = 1
    let particles: Particle[] = []
    const grid = new Map<number, Particle[]>()
    let reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const pointer = {
      active: false,
      x: 0,
      y: 0,
    }

    const buildGrid = () => {
      for (const bucket of grid.values()) {
        bucket.length = 0
      }

      gridColumns = Math.max(1, Math.ceil(width / PARTICLE_GRID_CELL_SIZE))

      for (const particle of particles) {
        const gridX = Math.floor(particle.x / PARTICLE_GRID_CELL_SIZE)
        const gridY = Math.floor(particle.y / PARTICLE_GRID_CELL_SIZE)
        const key = gridY * gridColumns + gridX
        let bucket = grid.get(key)

        if (!bucket) {
          bucket = []
          grid.set(key, bucket)
        }

        bucket.push(particle)
      }
    }

    const draw = () => {
      context.clearRect(0, 0, width, height)

      for (const particle of particles) {
        const gridX = Math.floor(particle.x / PARTICLE_GRID_CELL_SIZE)
        const gridY = Math.floor(particle.y / PARTICLE_GRID_CELL_SIZE)

        for (let offsetY = -1; offsetY <= 1; offsetY += 1) {
          for (let offsetX = -1; offsetX <= 1; offsetX += 1) {
            const bucket = grid.get((gridY + offsetY) * gridColumns + gridX + offsetX)

            if (!bucket) continue

            for (const next of bucket) {
              if (particle.id >= next.id) continue

              const dx = particle.x - next.x
              const dy = particle.y - next.y
              const distanceSquared = dx * dx + dy * dy

              if (distanceSquared > PARTICLE_LINK_DISTANCE_SQUARED) continue

              const opacity =
                (1 - distanceSquared / PARTICLE_LINK_DISTANCE_SQUARED) * 0.34

              context.beginPath()
              context.moveTo(particle.x, particle.y)
              context.lineTo(next.x, next.y)
              context.strokeStyle = `rgba(136, 136, 136, ${opacity})`
              context.lineWidth = 1
              context.stroke()
            }
          }
        }
      }

      for (const particle of particles) {
        context.beginPath()
        context.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2)
        context.fillStyle = 'rgba(136, 136, 136, 0.5)'
        context.fill()
      }
    }

    const update = (motionScale: number, frameScale: number) => {
      for (const particle of particles) {
        let baseReturnRate = 0.012

        if (pointer.active) {
          const dx = particle.x - pointer.x
          const dy = particle.y - pointer.y
          const distanceSquared = dx * dx + dy * dy

          if (distanceSquared < PARTICLE_REPULSE_RELAX_RADIUS_SQUARED) {
            const distance = Math.sqrt(distanceSquared)
            const safeDistance = distance || 1
            const fallbackAngle = Math.random() * Math.PI * 2
            const directionX =
              distance === 0 ? Math.cos(fallbackAngle) : dx / safeDistance
            const directionY =
              distance === 0 ? Math.sin(fallbackAngle) : dy / safeDistance
            const relaxPressure = 1 - distance / PARTICLE_REPULSE_RELAX_RADIUS
            const radialVelocity = particle.vx * directionX + particle.vy * directionY

            if (radialVelocity < 0) {
              const inwardCancel = Math.min(1, (0.34 + relaxPressure * 0.42) * frameScale)
              particle.vx -= directionX * radialVelocity * inwardCancel
              particle.vy -= directionY * radialVelocity * inwardCancel
            }

            if (distanceSquared < PARTICLE_REPULSE_RADIUS_SQUARED) {
              const pressure = 1 - distanceSquared / PARTICLE_REPULSE_RADIUS_SQUARED
              const repulseOffset = Math.min(pressure * 14 * frameScale, 42)

              particle.x += directionX * repulseOffset
              particle.y += directionY * repulseOffset
              particle.vx *= 0.9
              particle.vy *= 0.9
              baseReturnRate = 0.004
            }

            const tangentX = -directionY
            const tangentY = directionX
            const tangentVelocity = particle.vx * tangentX + particle.vy * tangentY

            if (radialVelocity < 0 && Math.abs(tangentVelocity) < 0.4) {
              const baseTangent = particle.baseVx * tangentX + particle.baseVy * tangentY
              const tangentDirection = baseTangent >= 0 ? 1 : -1

              particle.vx +=
                tangentX * tangentDirection * relaxPressure * 0.18 * frameScale
              particle.vy +=
                tangentY * tangentDirection * relaxPressure * 0.18 * frameScale
            }
          }
        }

        particle.vx += (particle.baseVx - particle.vx) * baseReturnRate * frameScale
        particle.vy += (particle.baseVy - particle.vy) * baseReturnRate * frameScale

        const speed = Math.hypot(particle.vx, particle.vy)
        if (speed > 7.5) {
          particle.vx = (particle.vx / speed) * 7.5
          particle.vy = (particle.vy / speed) * 7.5
        }

        particle.x += particle.vx * motionScale * frameScale
        particle.y += particle.vy * motionScale * frameScale

        if (particle.x < -particle.radius) {
          particle.x = width + particle.radius
          particle.y = Math.random() * height
        }

        if (particle.x > width + particle.radius) {
          particle.x = -particle.radius
          particle.y = Math.random() * height
        }

        if (particle.y < -particle.radius) {
          particle.y = height + particle.radius
          particle.x = Math.random() * width
        }

        if (particle.y > height + particle.radius) {
          particle.y = -particle.radius
          particle.x = Math.random() * width
        }
      }
    }

    const animate = (timestamp = performance.now()) => {
      if (document.hidden) {
        animationFrame = 0
        return
      }

      const elapsed = timestamp - lastFrameTime

      if (elapsed < targetFrameMs) {
        animationFrame = window.requestAnimationFrame(animate)
        return
      }

      const frameScale = Math.min(Math.max(elapsed / 16.67, 0.5), 4)
      lastFrameTime = timestamp

      update(reduceMotion ? 0.28 : 1, frameScale)
      buildGrid()
      draw()
      animationFrame = window.requestAnimationFrame(animate)
    }

    const startAnimation = () => {
      if (animationFrame || document.hidden) return

      lastFrameTime = performance.now()
      animationFrame = window.requestAnimationFrame(animate)
    }

    const stopAnimation = () => {
      if (!animationFrame) return

      window.cancelAnimationFrame(animationFrame)
      animationFrame = 0
    }

    const resize = () => {
      const rect = canvas.getBoundingClientRect()
      width = rect.width
      height = rect.height
      targetFrameMs = getTargetFrameMs(width, quiet)
      const dpr = getCanvasDpr(width, quiet)

      canvas.width = Math.floor(width * dpr)
      canvas.height = Math.floor(height * dpr)
      context.setTransform(dpr, 0, 0, dpr, 0, 0)
      particles = createParticles(width, height, getParticleCount(width, height, quiet))
      nextParticleId = particles.length
      canvas.dataset.particleCount = String(particles.length)
      canvas.dataset.particleFpsTarget = String(Math.round(1000 / targetFrameMs))
      buildGrid()
      draw()
    }

    const handlePointerMove = (event: PointerEvent) => {
      const rect = canvas.getBoundingClientRect()
      pointer.x = event.clientX - rect.left
      pointer.y = event.clientY - rect.top
      pointer.active =
        pointer.x >= 0 &&
        pointer.x <= rect.width &&
        pointer.y >= 0 &&
        pointer.y <= rect.height
    }

    const handlePointerLeave = () => {
      pointer.active = false
    }

    const handlePointerDown = () => {
      if (!pointer.active) return

      const availableParticleSlots = Math.max(
        0,
        getParticleLimit(width, quiet) - particles.length,
      )
      const pushCount = Math.min(PARTICLE_PUSH_COUNT, availableParticleSlots)

      for (let index = 0; index < pushCount; index += 1) {
        particles.push(createParticle(width, height, nextParticleId, pointer.x, pointer.y))
        nextParticleId += 1
      }

      canvas.dataset.particleCount = String(particles.length)
      buildGrid()
    }

    const handleMotionPreference = (event: MediaQueryListEvent) => {
      reduceMotion = event.matches
    }

    const handleVisibilityChange = () => {
      if (document.hidden) {
        stopAnimation()
        return
      }

      startAnimation()
    }

    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)')
    const resizeObserver = new ResizeObserver(resize)

    resizeObserver.observe(canvas)
    window.addEventListener('pointermove', handlePointerMove)
    window.addEventListener('pointerleave', handlePointerLeave)
    window.addEventListener('pointerdown', handlePointerDown)
    motionQuery.addEventListener('change', handleMotionPreference)
    document.addEventListener('visibilitychange', handleVisibilityChange)
    resize()
    startAnimation()

    return () => {
      stopAnimation()
      resizeObserver.disconnect()
      window.removeEventListener('pointermove', handlePointerMove)
      window.removeEventListener('pointerleave', handlePointerLeave)
      window.removeEventListener('pointerdown', handlePointerDown)
      motionQuery.removeEventListener('change', handleMotionPreference)
      document.removeEventListener('visibilitychange', handleVisibilityChange)
    }
  }, [quiet])

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="home-particle-field"
    />
  )
}

function App() {
  const [auth, setAuth] = useState<AuthState | null>(() => readStoredAuth())
  const [page, setPage] = useState<Page>(() =>
    readStoredAuth() ? 'home' : 'login',
  )
  const [username, setUsername] = useState('testuser')
  const [password, setPassword] = useState('123456')
  const [loginError, setLoginError] = useState('')
  const [isLoggingIn, setIsLoggingIn] = useState(false)

  const [memoryBodies, setMemoryBodies] = useState<MemoryBody[]>(INITIAL_MEMORIES)
  const [selectedMemoryId, setSelectedMemoryId] = useState('')
  const [memoryManageView, setMemoryManageView] = useState<MemoryManageView>('list')
  const [managedMemoryId, setManagedMemoryId] = useState('')
  const [memoryDetailTab, setMemoryDetailTab] = useState<MemoryDetailTab>('import')
  const [openMemoryMenuId, setOpenMemoryMenuId] = useState('')
  const [memoryStatus, setMemoryStatus] = useState('')
  const [isLoadingMemories, setIsLoadingMemories] = useState(false)
  const [createMemoryStep, setCreateMemoryStep] = useState(1)
  const [createMemoryName, setCreateMemoryName] = useState('')
  const [createMemorySummary, setCreateMemorySummary] = useState('')
  const [createMemoryText, setCreateMemoryText] = useState('')
  const [createMemoryFile, setCreateMemoryFile] = useState<File | null>(null)
  const [memoryImportText, setMemoryImportText] = useState('')
  const [memoryImportFile, setMemoryImportFile] = useState<File | null>(null)

  const [chatSessions, setChatSessions] = useState<ChatSessionRecord[]>([])
  const [activeChatId, setActiveChatId] = useState('')
  const [chatInput, setChatInput] = useState('')
  const [chatStatus, setChatStatus] = useState('')
  const [isSending, setIsSending] = useState(false)

  const [storyStatus, setStoryStatus] = useState('')
  const [isLoadingStory, setIsLoadingStory] = useState(false)

  const [diaryInput, setDiaryInput] = useState('')
  const [diaries, setDiaries] = useState<DiaryItem[]>([])
  const [diaryStatus, setDiaryStatus] = useState('')
  const [isSavingDiary, setIsSavingDiary] = useState(false)
  const [isLoadingDiaries, setIsLoadingDiaries] = useState(false)

  const [roles, setRoles] = useState<RoleItem[]>([])
  const [roleStatus, setRoleStatus] = useState('')
  const [isLoadingRoles, setIsLoadingRoles] = useState(false)

  const selectedMemory = useMemo(
    () => memoryBodies.find((memory) => memory.id === selectedMemoryId) ?? null,
    [memoryBodies, selectedMemoryId],
  )

  const managedMemory = useMemo(
    () => memoryBodies.find((memory) => memory.id === managedMemoryId) ?? null,
    [managedMemoryId, memoryBodies],
  )

  const memorySessions = useMemo(() => {
    return chatSessions
      .filter((session) => session.memoryId === selectedMemoryId)
      .toSorted((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt))
  }, [chatSessions, selectedMemoryId])

  const activeChat = useMemo(
    () => chatSessions.find((session) => session.id === activeChatId) ?? null,
    [activeChatId, chatSessions],
  )

  const activeSessionLabel = useMemo(() => {
    if (!activeChat) return '未创建'
    return (activeChat.backendSessionId || activeChat.id).slice(0, 8)
  }, [activeChat])

  const loadMemories = useCallback(async (userId = auth?.userId ?? '') => {
    if (!userId) return

    setMemoryStatus('')
    setIsLoadingMemories(true)

    try {
      const result = await requestJson<MemoryResponse[]>(
        `/memories?user_id=${encodeURIComponent(userId)}`,
      )
      setMemoryBodies(result.map(mapMemoryResponse))
    } catch (error) {
      setMemoryStatus(error instanceof Error ? error.message : '记忆体列表加载失败')
    } finally {
      setIsLoadingMemories(false)
    }
  }, [auth?.userId])

  useEffect(() => {
    if (auth) void loadMemories(auth.userId)
  }, [auth, loadMemories])

  useEffect(() => {
    if (page === 'memory' && memoryManageView === 'detail' && memoryDetailTab === 'diary') {
      void loadDiaries()
    }

    if (page === 'memory' && memoryManageView === 'detail' && memoryDetailTab === 'roles') {
      void loadRoles()
    }
  }, [memoryDetailTab, memoryManageView, page])

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setLoginError('')
    setIsLoggingIn(true)

    try {
      const result = await requestJson<LoginResponse>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      })

      const nextAuth = {
        token: result.token,
        userId: result.user_id,
      }

      storeAuth(nextAuth)
      setAuth(nextAuth)
      setPage('home')
    } catch (error) {
      setLoginError(error instanceof Error ? error.message : '登录失败')
    } finally {
      setIsLoggingIn(false)
    }
  }

  function handleLogout() {
    clearStoredAuth()
    setAuth(null)
    setSelectedMemoryId('')
    setActiveChatId('')
    setChatInput('')
    setChatStatus('')
    setPage('login')
  }

  function openChatEntry() {
    setSelectedMemoryId('')
    setActiveChatId('')
    setChatStatus('')
    if (auth) void loadMemories(auth.userId)
    setPage('chat')
  }

  function openMemoryHome() {
    setMemoryManageView('list')
    setManagedMemoryId('')
    setMemoryDetailTab('import')
    setOpenMemoryMenuId('')
    setStoryStatus('')
    if (auth) void loadMemories(auth.userId)
    setPage('memory')
  }

  function openMemoryDetail(memoryId: string, tab: MemoryDetailTab = 'import') {
    setManagedMemoryId(memoryId)
    setMemoryDetailTab(tab)
    setMemoryManageView('detail')
    setOpenMemoryMenuId('')
    setStoryStatus('')
  }

  function openCreateMemory() {
    setCreateMemoryStep(1)
    setCreateMemoryName('')
    setCreateMemorySummary('')
    setCreateMemoryText('')
    setCreateMemoryFile(null)
    setOpenMemoryMenuId('')
    setStoryStatus('')
    setMemoryManageView('create')
  }

  async function deleteMemory(memoryId: string) {
    setMemoryStatus('')
    setStoryStatus('')

    try {
      await requestJson<{ status: string }>(`/memories/${memoryId}`, {
        method: 'DELETE',
      })

      setMemoryBodies((items) => items.filter((memory) => memory.id !== memoryId))
      setChatSessions((items) => items.filter((session) => session.memoryId !== memoryId))

      if (selectedMemoryId === memoryId) {
        setSelectedMemoryId('')
        setActiveChatId('')
      }

      if (managedMemoryId === memoryId) {
        setManagedMemoryId('')
        setMemoryManageView('list')
      }

      setOpenMemoryMenuId('')
      setMemoryStatus('记忆体已删除')
    } catch (error) {
      const message = error instanceof Error ? error.message : '删除记忆体失败'
      setMemoryStatus(message)
      setStoryStatus(message)
    }
  }

  async function createMemory() {
    const name = createMemoryName.trim()
    const summary = createMemorySummary.trim()

    if (!name) {
      setStoryStatus('请输入记忆体名称')
      setCreateMemoryStep(1)
      return
    }

    if (!auth) {
      setStoryStatus('请先登录')
      return
    }

    setStoryStatus('正在创建记忆体...')
    setIsLoadingStory(true)

    try {
      const created = await requestJson<MemoryResponse>('/memories', {
        method: 'POST',
        body: JSON.stringify({
          user_id: auth.userId,
          name,
          summary: summary || '自定义记忆体。',
        }),
      })
      const memory = mapMemoryResponse(created)

      setMemoryBodies((items) => [memory, ...items])
      setManagedMemoryId(memory.id)
      setMemoryDetailTab('import')
      setMemoryManageView('detail')

      if (createMemoryFile || createMemoryText.trim()) {
        await uploadMemoryData(memory.id, createMemoryFile, createMemoryText)
      } else {
        setStoryStatus(`已创建「${memory.name}」，可继续上传数据。`)
      }

      setCreateMemoryFile(null)
      setCreateMemoryText('')
      void loadMemories(auth.userId)
    } catch (error) {
      setStoryStatus(error instanceof Error ? error.message : '创建记忆体失败')
    } finally {
      setIsLoadingStory(false)
    }
  }

  function createLocalSession(
    memory: MemoryBody,
    overrides: Partial<ChatSessionRecord> = {},
  ) {
    const now = new Date().toISOString()
    const session: ChatSessionRecord = {
      id: crypto.randomUUID(),
      backendSessionId: '',
      memoryId: memory.id,
      title: '新的对话',
      messages: getInitialMessages(memory.name),
      createdAt: now,
      updatedAt: now,
      ...overrides,
    }

    setChatSessions((items) => [session, ...items])
    setActiveChatId(session.id)
    return session
  }

  async function loadSessionMessages(session: ChatSessionRecord) {
    if (!session.backendSessionId) return

    setChatStatus('')

    try {
      const result = await requestJson<BackendMessageItem[]>(
        `/chat/sessions/${session.backendSessionId}/messages`,
      )
      setChatSessions((items) =>
        items.map((item) =>
          item.id === session.id
            ? {
                ...item,
                messages:
                  result.length > 0
                    ? result.map((message) => ({
                        id: message.message_id,
                        sender: message.sender,
                        content: message.content,
                      }))
                    : item.messages,
              }
            : item,
        ),
      )
    } catch (error) {
      setChatStatus(error instanceof Error ? error.message : '会话消息加载失败')
    }
  }

  async function loadSessionsForMemory(memory: MemoryBody) {
    if (!auth) return

    setChatStatus('正在加载历史对话...')

    try {
      const result = await requestJson<BackendSessionItem[]>(
        `/chat/sessions?user_id=${encodeURIComponent(auth.userId)}&memory_id=${encodeURIComponent(memory.id)}`,
      )
      const sessions = result.map((session) => ({
        id: session.session_id,
        backendSessionId: session.session_id,
        memoryId: session.memory_id || memory.id,
        title: session.title || '新的对话',
        messages: getInitialMessages(memory.name),
        createdAt: session.created_at || new Date().toISOString(),
        updatedAt: session.updated_at || session.created_at || new Date().toISOString(),
      }))

      setChatSessions((items) => [
        ...items.filter((session) => session.memoryId !== memory.id),
        ...sessions,
      ])

      if (sessions.length > 0) {
        setActiveChatId(sessions[0].id)
        void loadSessionMessages(sessions[0])
      } else {
        createLocalSession(memory)
      }

      setChatStatus('')
    } catch (error) {
      setChatStatus(error instanceof Error ? error.message : '历史对话加载失败')

      const lastSession = chatSessions
        .filter((session) => session.memoryId === memory.id)
        .toSorted((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt))[0]

      if (lastSession) {
        setActiveChatId(lastSession.id)
      } else {
        createLocalSession(memory)
      }
    }
  }

  function selectMemory(memory: MemoryBody) {
    setSelectedMemoryId(memory.id)
    setChatStatus('')
    void loadSessionsForMemory(memory)
  }

  async function createNewChatForSelectedMemory() {
    if (!selectedMemory) {
      setChatStatus('请先选择记忆体')
      return
    }

    if (!auth) {
      setChatStatus('请先登录')
      return
    }

    setChatStatus('正在创建对话...')

    try {
      const result = await requestJson<{ session_id: string; memory_id?: string }>(
        '/chat/sessions',
        {
          method: 'POST',
          body: JSON.stringify({
            user_id: auth.userId,
            memory_id: selectedMemory.id,
          }),
        },
      )

      createLocalSession(selectedMemory, {
        id: result.session_id,
        backendSessionId: result.session_id,
        memoryId: result.memory_id || selectedMemory.id,
      })
      setChatInput('')
      setChatStatus('已新建对话')
    } catch (error) {
      setChatStatus(error instanceof Error ? error.message : '新建对话失败')
    }
  }

  async function ensureBackendSession(session: ChatSessionRecord) {
    if (session.backendSessionId) return session.backendSessionId
    if (!auth) throw new Error('请先登录')

    const result = await requestJson<{ session_id: string }>('/chat/sessions', {
      method: 'POST',
      body: JSON.stringify({
        user_id: auth.userId,
        memory_id: session.memoryId,
      }),
    })

    setChatSessions((items) =>
      items.map((item) =>
        item.id === session.id
          ? {
              ...item,
              backendSessionId: result.session_id,
              updatedAt: new Date().toISOString(),
            }
          : item,
      ),
    )

    return result.session_id
  }

  async function deleteActiveChat() {
    if (!activeChat) {
      setChatStatus('当前没有可删除的对话')
      return
    }

    setChatStatus('正在删除对话...')

    try {
      if (activeChat.backendSessionId) {
        await requestJson<{ status: string }>(`/chat/sessions/${activeChat.backendSessionId}`, {
          method: 'DELETE',
        })
      }

      const remaining = chatSessions.filter((session) => session.id !== activeChat.id)
      const nextSession = remaining
        .filter((session) => session.memoryId === selectedMemoryId)
        .toSorted((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt))[0]

      setChatSessions(remaining)

      if (nextSession) {
        setActiveChatId(nextSession.id)
      } else if (selectedMemory) {
        createLocalSession(selectedMemory)
      } else {
        setActiveChatId('')
      }

      setChatStatus('对话已删除')
    } catch (error) {
      setChatStatus(error instanceof Error ? error.message : '删除对话失败')
    }
  }

  async function handleSendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const content = chatInput.trim()

    if (!content) {
      setChatStatus('请输入内容')
      return
    }

    if (!activeChat) {
      setChatStatus('请先选择记忆体')
      return
    }

    const now = new Date().toISOString()
    const userMessage: Message = {
      id: crypto.randomUUID(),
      sender: 'user',
      content,
    }

    setIsSending(true)
    setChatStatus('')
    setChatInput('')
    setChatSessions((items) =>
      items.map((session) =>
        session.id === activeChat.id
          ? {
              ...session,
              title:
                session.title === '新的对话'
                  ? makeSessionTitle(content)
                  : session.title,
              messages: [...session.messages, userMessage],
              updatedAt: now,
            }
          : session,
      ),
    )

    try {
      const backendSessionId = await ensureBackendSession(activeChat)
      const result = await requestJson<{ response: string }>('/chat', {
        method: 'POST',
        body: JSON.stringify({
          session_id: backendSessionId,
          user_input: content,
          memory_id: activeChat.memoryId,
        }),
      })

      setChatSessions((items) =>
        items.map((session) =>
          session.id === activeChat.id
            ? {
                ...session,
                backendSessionId,
                messages: [
                  ...session.messages,
                  {
                    id: crypto.randomUUID(),
                    sender: 'ai',
                    content: result.response,
                  },
                ],
                updatedAt: new Date().toISOString(),
              }
            : session,
        ),
      )
    } catch (error) {
      setChatSessions((items) =>
        items.map((session) =>
          session.id === activeChat.id
            ? {
                ...session,
                messages: [
                  ...session.messages,
                  {
                    id: crypto.randomUUID(),
                    sender: 'system',
                    content: error instanceof Error ? error.message : '发送失败',
                  },
                ],
                updatedAt: new Date().toISOString(),
              }
            : session,
        ),
      )
    } finally {
      setIsSending(false)
    }
  }

  async function uploadMemoryData(
    memoryId = managedMemoryId,
    file = memoryImportFile,
    text = memoryImportText,
  ) {
    if (!auth) {
      setStoryStatus('请先登录')
      return
    }

    const trimmedText = text.trim()
    if (!file && !trimmedText) {
      setStoryStatus('请上传 txt 文件或粘贴文本内容')
      return
    }

    setStoryStatus('')
    setIsLoadingStory(true)

    try {
      const formData = new FormData()
      formData.append('user_id', auth.userId)

      if (file) formData.append('file', file)
      if (trimmedText) formData.append('text', trimmedText)

      const result = await requestJson<UploadMemoryResponse>(`/memories/${memoryId}/upload`, {
        method: 'POST',
        body: formData,
      })

      setStoryStatus(result.message)
      setMemoryBodies((items) =>
        items.map((item) =>
          item.id === memoryId
            ? {
                ...item,
                source: result.file_path || item.source,
                vectorPath: result.vector_path || item.vectorPath,
                importStatus: normalizeImportStatus(result.import_status),
                updatedAt: new Date().toISOString(),
              }
            : item,
        ),
      )
      setMemoryImportFile(null)
      setMemoryImportText('')
    } catch (error) {
      setStoryStatus(error instanceof Error ? error.message : '导入失败')
      setMemoryBodies((items) =>
        items.map((item) =>
          item.id === memoryId
            ? {
                ...item,
                importStatus: 'failed',
                updatedAt: new Date().toISOString(),
              }
            : item,
        ),
      )
    } finally {
      setIsLoadingStory(false)
    }
  }

  async function loadDiaries() {
    setDiaryStatus('')
    setIsLoadingDiaries(true)
    try {
      const result = await requestJson<DiaryItem[]>(
        `/diaries?user_id=${DIARY_USER_ID}&page=1&page_size=20`,
      )
      setDiaries(result)
    } catch (error) {
      setDiaryStatus(error instanceof Error ? error.message : '日记加载失败')
    } finally {
      setIsLoadingDiaries(false)
    }
  }

  async function saveDiary(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const content = diaryInput.trim()
    if (!content) {
      setDiaryStatus('请输入日记内容')
      return
    }

    setDiaryStatus('')
    setIsSavingDiary(true)
    try {
      await requestJson<{ diary_id: number; status: string }>('/diaries', {
        method: 'POST',
        body: JSON.stringify({
          user_id: DIARY_USER_ID,
          content,
          content_type: 'text',
        }),
      })

      setDiaryInput('')
      setDiaryStatus('日记已保存')
      await loadDiaries()
    } catch (error) {
      setDiaryStatus(error instanceof Error ? error.message : '保存失败')
    } finally {
      setIsSavingDiary(false)
    }
  }

  async function loadRoles() {
    setRoleStatus('')
    setIsLoadingRoles(true)
    try {
      const result = await requestJson<RoleItem[]>('/roles')
      setRoles(result)
    } catch (error) {
      setRoleStatus(error instanceof Error ? error.message : '角色加载失败')
    } finally {
      setIsLoadingRoles(false)
    }
  }

  if (!auth || page === 'login') {
    return (
      <main className="auth-shell">
        <HomeParticleField />

        <section className="auth-card page-enter">
          <p className="eyebrow">心语时光</p>
          <h1>欢迎回来</h1>
          <p className="muted">继续你的对话，或整理记忆体。</p>

          <form className="stack" onSubmit={handleLogin}>
            <label>
              用户名
              <input
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                autoComplete="username"
              />
            </label>
            <label>
              密码
              <input
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                type="password"
                autoComplete="current-password"
              />
            </label>
            {loginError && <p className="status error">{loginError}</p>}
            <button className="primary-button" disabled={isLoggingIn}>
              {isLoggingIn ? '登录中...' : '登录'}
            </button>
          </form>
        </section>
      </main>
    )
  }

  return (
    <main className="app-shell">
      <HomeParticleField quiet={page !== 'home'} />

      <header className="topbar">
        <button className="brand-button" onClick={() => setPage('home')}>
          心语时光
        </button>
        <div className="user-strip">
          <span>{auth.userId}</span>
          <button className="ghost-button" onClick={handleLogout}>
            退出
          </button>
        </div>
      </header>

      {page === 'home' && (
        <section className="home page-enter">
          <div className="hero-copy">
            <h1>心语时光</h1>
            <p>选择记忆体后开始对话，或整理你的记忆资料。</p>
          </div>

          <div className="choice-grid">
            <button className="choice-card" onClick={openChatEntry}>
              <span>对话</span>
              <strong>选择记忆体并继续交流</strong>
              <small>进入</small>
            </button>
            <button className="choice-card" onClick={openMemoryHome}>
              <span>管理记忆体</span>
              <strong>导入文本，维护日记与角色参数</strong>
              <small>进入</small>
            </button>
          </div>
        </section>
      )}

      {page === 'chat' && !selectedMemory && (
        <section className="workspace page-enter">
          <div className="workspace-head">
            <button className="back-button" onClick={() => setPage('home')}>
              返回首页
            </button>
            <div>
              <p className="eyebrow">Memory Select</p>
              <h1>选择记忆体</h1>
            </div>
          </div>

          <section className="memory-picker-panel">
            {isLoadingMemories && <p className="status">正在加载记忆体...</p>}
            {memoryStatus && <p className="status">{memoryStatus}</p>}
            {memoryBodies.length === 0 ? (
              <div className="empty-state">
                <p className="eyebrow">暂无记忆体</p>
                <h2>暂无可选择的记忆体</h2>
                <p className="muted">请前往管理记忆体页面维护资料。</p>
              </div>
            ) : (
              <div className="memory-card-grid">
                {memoryBodies.map((memory) => (
                  <button
                    className="memory-choice-card"
                    key={memory.id}
                    onClick={() => selectMemory(memory)}
                  >
                    <strong>{memory.name}</strong>
                    <p>{memory.summary}</p>
                    <small>点击进入对话</small>
                  </button>
                ))}
              </div>
            )}
          </section>
        </section>
      )}

      {page === 'chat' && selectedMemory && (
        <section className="chat-workspace page-enter">
          <aside className="conversation-sidebar">
            <button className="back-button full" onClick={() => setSelectedMemoryId('')}>
              更换记忆体
            </button>
            <div className="sidebar-title">
              <p className="eyebrow">当前记忆体</p>
              <h2>{selectedMemory.name}</h2>
              <p>{selectedMemory.summary}</p>
            </div>
            <button
              className="primary-button full"
              onClick={() => void createNewChatForSelectedMemory()}
            >
              新建对话
            </button>
            <nav className="conversation-list" aria-label="历史对话">
              {memorySessions.map((session) => (
                <button
                  className={session.id === activeChatId ? 'active' : ''}
                  key={session.id}
                  onClick={() => {
                    setActiveChatId(session.id)
                    setChatStatus('')
                    void loadSessionMessages(session)
                  }}
                >
                  <strong>{session.title}</strong>
                  <span>{formatTime(session.updatedAt)}</span>
                </button>
              ))}
            </nav>
          </aside>

          <section className="large-chat-panel">
            <div className="large-chat-head">
              <div>
                <p className="eyebrow">当前会话 {activeSessionLabel}</p>
                <h1>{selectedMemory.name}</h1>
                <p className="chat-subtitle">{activeChat?.title ?? '新的对话'}</p>
              </div>
              <button
                className="chat-head-action"
                onClick={deleteActiveChat}
                aria-label="删除当前对话"
                title="删除当前对话"
              >
                ×
              </button>
            </div>

            <div className="message-list">
              {(activeChat?.messages ?? []).map((message) => (
                <article
                  className={`message message-${message.sender}`}
                  key={message.id}
                >
                  <span>
                    {message.sender === 'user'
                      ? '你'
                      : message.sender === 'ai'
                        ? 'AI'
                        : '系统'}
                  </span>
                  <p>{message.content}</p>
                </article>
              ))}
              {isSending && (
                <article className="message message-system">
                  <span>系统</span>
                  <p>正在等待 AI 回复...</p>
                </article>
              )}
            </div>
            {chatStatus && <p className="status">{chatStatus}</p>}
            <form className="composer chat-composer" onSubmit={handleSendMessage}>
              <div className="composer-surface">
                <input
                  value={chatInput}
                  onChange={(event) => setChatInput(event.target.value)}
                  placeholder={`和「${selectedMemory.name}」继续聊`}
                />
              </div>
              <button className="send-button" disabled={isSending} aria-label="发送消息">
                发送
              </button>
            </form>
          </section>
        </section>
      )}

      {page === 'memory' && (
        <section className="workspace page-enter">
          <div className="workspace-head">
            <button
              className="back-button"
              onClick={() => {
                if (memoryManageView === 'list') {
                  setPage('home')
                } else {
                  setMemoryManageView('list')
                  setManagedMemoryId('')
                }
              }}
            >
              {memoryManageView === 'list' ? '返回首页' : '返回列表'}
            </button>
            <div>
              <p className="eyebrow">Memory</p>
              <h1>
                {memoryManageView === 'create'
                  ? '新增记忆体'
                  : memoryManageView === 'detail'
                    ? managedMemory?.name || '记忆体详情'
                    : '管理记忆体'}
              </h1>
            </div>
          </div>

          {memoryManageView === 'list' && (
            <div className="memory-dashboard">
              <section className="memory-list-panel">
                <div className="section-head">
                  <div>
                    <p className="eyebrow">已有记忆体</p>
                    <h2>选择一个记忆体继续维护</h2>
                  </div>
                  <button
                    className="ghost-button"
                    onClick={() => auth && void loadMemories(auth.userId)}
                    disabled={isLoadingMemories}
                  >
                    {isLoadingMemories ? '刷新中...' : '刷新'}
                  </button>
                </div>
                {memoryStatus && <p className="status">{memoryStatus}</p>}

                {memoryBodies.length === 0 ? (
                  <div className="empty-state">
                    <p className="eyebrow">暂无记忆体</p>
                    <h2>从右侧新增一个记忆体</h2>
                    <p className="muted">新建后会保存到当前后端数据库。</p>
                  </div>
                ) : (
                  <div className="managed-memory-grid">
                    {memoryBodies.map((memory) => (
                      <article className="managed-memory-card" key={memory.id}>
                        <button
                          className="managed-memory-main"
                          onClick={() => openMemoryDetail(memory.id)}
                        >
                          <span className={`status-pill status-${memory.importStatus}`}>
                            {formatImportStatus(memory.importStatus)}
                          </span>
                          <h3>{memory.name}</h3>
                          <p>{memory.summary}</p>
                          <dl>
                            <div>
                              <dt>创建时间</dt>
                              <dd>{formatTime(memory.createdAt)}</dd>
                            </div>
                            <div>
                              <dt>更新时间</dt>
                              <dd>{formatTime(memory.updatedAt)}</dd>
                            </div>
                          </dl>
                        </button>
                        <div className="memory-card-actions">
                          <button
                            className="more-button"
                            aria-label={`${memory.name} 快捷操作`}
                            onClick={() =>
                              setOpenMemoryMenuId((current) =>
                                current === memory.id ? '' : memory.id,
                              )
                            }
                          >
                            ...
                          </button>
                          {openMemoryMenuId === memory.id && (
                            <div className="memory-menu">
                              <button onClick={() => openMemoryDetail(memory.id, 'import')}>
                                导入数据
                              </button>
                              <button onClick={() => openMemoryDetail(memory.id, 'roles')}>
                                查看参数
                              </button>
                              <button
                                className="danger-menu-item"
                                onClick={() => void deleteMemory(memory.id)}
                              >
                                删除记忆体
                              </button>
                            </div>
                          )}
                        </div>
                      </article>
                    ))}
                  </div>
                )}
              </section>

              <aside className="memory-create-aside">
                <p className="eyebrow">新增记忆体</p>
                <h2>创建新的记忆空间</h2>
                <p className="muted">按步骤填写名称、简介，并上传 txt 或粘贴文本。</p>
                <button className="primary-button full" onClick={openCreateMemory}>
                  新增记忆体
                </button>
              </aside>
            </div>
          )}

          {memoryManageView === 'detail' && managedMemory && (
            <div className="memory-detail-layout">
              <aside className="memory-detail-side">
                <span className={`status-pill status-${managedMemory.importStatus}`}>
                  {formatImportStatus(managedMemory.importStatus)}
                </span>
                <h2>{managedMemory.name}</h2>
                <p>{managedMemory.summary}</p>
                <dl>
                  <div>
                    <dt>更新时间</dt>
                    <dd>{formatTime(managedMemory.updatedAt)}</dd>
                  </div>
                </dl>
                <button
                  className="danger-button full"
                  onClick={() => void deleteMemory(managedMemory.id)}
                >
                  删除记忆体
                </button>
              </aside>

              <section className="memory-detail-panel">
                <nav className="memory-tabbar" aria-label="记忆体详情功能">
                  <button
                    className={memoryDetailTab === 'import' ? 'active' : ''}
                    onClick={() => setMemoryDetailTab('import')}
                  >
                    导入数据
                  </button>
                  <button
                    className={memoryDetailTab === 'roles' ? 'active' : ''}
                    onClick={() => setMemoryDetailTab('roles')}
                  >
                    查看参数
                  </button>
                  <button
                    className={memoryDetailTab === 'diary' ? 'active' : ''}
                    onClick={() => setMemoryDetailTab('diary')}
                  >
                    其他功能
                  </button>
                </nav>

                {memoryDetailTab === 'import' && (
                  <section className="panel-section">
                    <p className="eyebrow">导入数据</p>
                    <h2>上传 txt 文件或粘贴文本</h2>
                    <label>
                      上传文件
                      <input
                        accept=".txt,text/plain"
                        type="file"
                        onChange={(event) =>
                          setMemoryImportFile(event.target.files?.[0] ?? null)
                        }
                      />
                    </label>
                    {memoryImportFile && (
                      <p className="status">已选择：{memoryImportFile.name}</p>
                    )}
                    <label>
                      粘贴文本
                      <textarea
                        value={memoryImportText}
                        onChange={(event) => setMemoryImportText(event.target.value)}
                        placeholder="把要导入这个记忆体的文本粘贴在这里"
                      />
                    </label>
                    <button
                      className="primary-button fit"
                      onClick={() => void uploadMemoryData(managedMemory.id)}
                      disabled={isLoadingStory}
                    >
                      {isLoadingStory ? '导入中...' : '导入数据'}
                    </button>
                    {storyStatus && <p className="status">{storyStatus}</p>}
                  </section>
                )}

                {memoryDetailTab === 'roles' && (
                  <section className="panel-section">
                    <div className="section-head">
                      <div>
                        <p className="eyebrow">角色参数</p>
                        <h2>当前可用角色参数</h2>
                      </div>
                      <button className="ghost-button" onClick={loadRoles}>
                        {isLoadingRoles ? '刷新中...' : '刷新'}
                      </button>
                    </div>
                    <p className="muted">当前参数来自全局角色接口，暂未按记忆体区分。</p>
                    {roleStatus && <p className="status">{roleStatus}</p>}
                    <div className="role-grid">
                      {roles.length === 0 ? (
                        <p className="muted">暂无角色数据。</p>
                      ) : (
                        roles.map((role) => (
                          <article className="role-card" key={role.role_id}>
                            <h3>{role.role_name}</h3>
                            <div className="meter-row">
                              <span>温柔度</span>
                              <meter value={role.gentleness} max="1" />
                              <strong>{role.gentleness.toFixed(2)}</strong>
                            </div>
                            <div className="meter-row">
                              <span>理性值</span>
                              <meter value={role.rationality} max="1" />
                              <strong>{role.rationality.toFixed(2)}</strong>
                            </div>
                          </article>
                        ))
                      )}
                    </div>
                  </section>
                )}

                {memoryDetailTab === 'diary' && (
                  <section className="panel-section">
                    <p className="eyebrow">其他功能</p>
                    <h2>情绪日记</h2>
                    <form className="diary-form" onSubmit={saveDiary}>
                      <textarea
                        value={diaryInput}
                        onChange={(event) => setDiaryInput(event.target.value)}
                        placeholder="写下今天的记录"
                      />
                      <button className="primary-button fit" disabled={isSavingDiary}>
                        {isSavingDiary ? '保存中...' : '保存日记'}
                      </button>
                    </form>
                    <div className="section-head">
                      <h3>日记列表</h3>
                      <button className="ghost-button" onClick={loadDiaries}>
                        {isLoadingDiaries ? '刷新中...' : '刷新'}
                      </button>
                    </div>
                    {diaryStatus && <p className="status">{diaryStatus}</p>}
                    <div className="item-list">
                      {diaries.length === 0 ? (
                        <p className="muted">暂无日记数据。</p>
                      ) : (
                        diaries.map((diary) => (
                          <article className="data-card" key={diary.diary_id}>
                            <p>{diary.content}</p>
                            <dl>
                              <div>
                                <dt>标签</dt>
                                <dd>{diary.emotion_tags || '无'}</dd>
                              </div>
                              <div>
                                <dt>AI 回复</dt>
                                <dd>{diary.ai_reply || '无'}</dd>
                              </div>
                              <div>
                                <dt>时间</dt>
                                <dd>{diary.create_time}</dd>
                              </div>
                            </dl>
                          </article>
                        ))
                      )}
                    </div>
                  </section>
                )}
              </section>
            </div>
          )}

          {memoryManageView === 'create' && (
            <section className="memory-create-flow">
              <div className="create-steps" aria-label="新增记忆体步骤">
                {[1, 2, 3].map((step) => (
                  <button
                    className={createMemoryStep === step ? 'active' : ''}
                    key={step}
                    onClick={() => setCreateMemoryStep(step)}
                  >
                    {step}
                  </button>
                ))}
              </div>

              {createMemoryStep === 1 && (
                <div className="panel-section">
                  <p className="eyebrow">步骤一</p>
                  <h2>命名记忆体</h2>
                  <label>
                    名称
                    <input
                      value={createMemoryName}
                      onChange={(event) => setCreateMemoryName(event.target.value)}
                      placeholder="例如：旅行回忆"
                    />
                  </label>
                  <label>
                    简介
                    <textarea
                      value={createMemorySummary}
                      onChange={(event) => setCreateMemorySummary(event.target.value)}
                      placeholder="写一句这个记忆体的用途"
                    />
                  </label>
                  <button className="primary-button fit" onClick={() => setCreateMemoryStep(2)}>
                    下一步
                  </button>
                </div>
              )}

              {createMemoryStep === 2 && (
                <div className="panel-section">
                  <p className="eyebrow">步骤二</p>
                  <h2>导入初始数据</h2>
                  <label>
                    上传 txt 文件
                    <input
                      accept=".txt,text/plain"
                      type="file"
                      onChange={(event) =>
                        setCreateMemoryFile(event.target.files?.[0] ?? null)
                      }
                    />
                  </label>
                  {createMemoryFile && (
                    <p className="status">已选择：{createMemoryFile.name}</p>
                  )}
                  <label>
                    粘贴文本
                    <textarea
                      value={createMemoryText}
                      onChange={(event) => setCreateMemoryText(event.target.value)}
                      placeholder="可选。创建后会导入到这个记忆体。"
                    />
                  </label>
                  <div className="action-row">
                    <button className="ghost-button" onClick={() => setCreateMemoryStep(1)}>
                      上一步
                    </button>
                    <button className="primary-button" onClick={() => setCreateMemoryStep(3)}>
                      下一步
                    </button>
                  </div>
                </div>
              )}

              {createMemoryStep === 3 && (
                <div className="panel-section">
                  <p className="eyebrow">步骤三</p>
                  <h2>确认创建</h2>
                  <dl className="confirm-list">
                    <div>
                      <dt>名称</dt>
                      <dd>{createMemoryName || '未填写'}</dd>
                    </div>
                    <div>
                      <dt>简介</dt>
                      <dd>{createMemorySummary || '自定义记忆体。'}</dd>
                    </div>
                    <div>
                      <dt>初始数据</dt>
                      <dd>
                        {createMemoryFile?.name ||
                          (createMemoryText.trim() ? '已填写粘贴文本' : '暂不导入')}
                      </dd>
                    </div>
                  </dl>
                  {storyStatus && <p className="status">{storyStatus}</p>}
                  <div className="action-row">
                    <button className="ghost-button" onClick={() => setCreateMemoryStep(2)}>
                      上一步
                    </button>
                    <button
                      className="primary-button"
                      onClick={() => void createMemory()}
                      disabled={isLoadingStory}
                    >
                      完成创建
                    </button>
                  </div>
                </div>
              )}
            </section>
          )}
        </section>
      )}
    </main>
  )
}

export default App
