# 心语时光前端

这是心语时光的 React + TypeScript + Vite 前端。

## 启动

```powershell
npm install
npm run dev -- --host 127.0.0.1
```

访问：

```text
http://127.0.0.1:5173/
```

开发服务器会把 `/api` 请求代理到：

```text
http://localhost:8000
```

## 验证

```powershell
npm run build
npm run lint
```

## 当前页面

- 登录页
- 首页入口
- 对话前选择记忆体
- 记忆体对话页
- 历史会话侧边栏
- 管理记忆体
- 新建记忆体
- 上传 txt 或粘贴文本导入
- 查看角色参数
- 情绪日记
