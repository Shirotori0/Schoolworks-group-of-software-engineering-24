param(
  [switch]$Api
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Split-Path -Parent $root
$frontend = Join-Path $root "frontend"

Write-Host "Checking backend Python files..."
Push-Location $repoRoot
python -m py_compile `
  heart-time\backend\config.py `
  heart-time\backend\main.py `
  heart-time\backend\api\memories.py `
  heart-time\backend\api\chat_sessions.py `
  heart-time\backend\api\roles.py `
  heart-time\backend\api\diaries.py `
  heart-time\ai\agent\agent.py `
  heart-time\ai\rag\embedding\embedder.py
Pop-Location

Write-Host "Building frontend..."
Push-Location $frontend
npm run build
npm run lint
Pop-Location

if ($Api) {
  Write-Host "Checking API smoke flow through http://127.0.0.1:5173/api/v1..."
  $baseUrl = "http://127.0.0.1:5173/api/v1"

  Invoke-RestMethod `
    -Method Post `
    -Uri "$baseUrl/auth/login" `
    -ContentType "application/json" `
    -Body '{"username":"testuser","password":"123456"}' | Out-Null

  Invoke-RestMethod `
    -Method Get `
    -Uri "$baseUrl/roles" | Out-Null

  $memories = Invoke-RestMethod `
    -Method Get `
    -Uri "$baseUrl/memories?user_id=user_001"
  if (-not ($memories | Where-Object { $_.memory_id -eq "default-memory" })) {
    throw "Default memory default-memory was not returned for user_001"
  }

  $created = Invoke-RestMethod `
    -Method Post `
    -Uri "$baseUrl/memories" `
    -ContentType "application/json" `
    -Body '{"user_id":"user_001","name":"verify-smoke","summary":"verify script smoke test"}'

  $memoryId = $created.memory_id

  try {
    $uploadResponse = curl.exe -s -X POST "$baseUrl/memories/$memoryId/upload" `
      -F "user_id=user_001" `
      -F "text=verify smoke memory text"
    $upload = $uploadResponse | ConvertFrom-Json
    if ($upload.import_status -ne "imported") {
      throw "Memory upload did not finish as imported: $uploadResponse"
    }

    $sessionBody = @{
      user_id = "user_001"
      memory_id = $memoryId
    } | ConvertTo-Json -Compress
    $session = Invoke-RestMethod `
      -Method Post `
      -Uri "$baseUrl/chat/sessions" `
      -ContentType "application/json" `
      -Body $sessionBody

    $chatBody = @{
      session_id = $session.session_id
      user_input = "verify smoke chat"
      memory_id = $memoryId
    } | ConvertTo-Json -Compress
    $chat = Invoke-RestMethod `
      -Method Post `
      -Uri "$baseUrl/chat" `
      -ContentType "application/json" `
      -Body $chatBody
    if (-not $chat.response) {
      throw "Chat response is empty"
    }

    $messages = Invoke-RestMethod `
      -Method Get `
      -Uri "$baseUrl/chat/sessions/$($session.session_id)/messages"
    if ($messages.Count -lt 2) {
      throw "Expected at least 2 history messages, got $($messages.Count)"
    }
  }
  finally {
    if ($memoryId) {
      Invoke-RestMethod `
        -Method Delete `
        -Uri "$baseUrl/memories/$memoryId" | Out-Null
    }
  }
}

Write-Host "Verification complete."
