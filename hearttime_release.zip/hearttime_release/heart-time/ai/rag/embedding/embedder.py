import hashlib
import os

from ... import config  # noqa: F401

# 用户输入文本转换为向量的模块，使用OpenAI的API进行文本嵌入
from openai import OpenAI
from typing import List

class Embedder:
    def __init__(self):
        self.api_key = os.getenv("DASHSCOPE_API_KEY")
        self.client = None
        self.model = "text-embedding-v4"
        self.local_dimensions = 256

    def _get_client(self):
        if self.client:
            return self.client

        if not self.api_key:
            return None

        self.client = OpenAI(
            api_key=self.api_key,
            base_url="https://dashscope.aliyuncs.com/compatible-mode/v1"
        )
        return self.client

    def _local_embed(self, text: str) -> List[float]:
        vector = [0.0] * self.local_dimensions
        tokens = text.split() or [text]

        for token in tokens:
            digest = hashlib.sha256(token.encode("utf-8")).digest()
            for index, value in enumerate(digest):
                bucket = index % self.local_dimensions
                vector[bucket] += (value / 255.0) - 0.5

        norm = sum(item * item for item in vector) ** 0.5
        if norm == 0:
            return vector

        return [item / norm for item in vector]

    # 文本转换向量
    def embed(self, text: str) -> List[float]:
        client = self._get_client()
        if client is None:
            return self._local_embed(text)

        response = client.embeddings.create(
            model=self.model,
            input=text
        )
        return response.data[0].embedding

    # 批量转换向量
    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        client = self._get_client()
        if client is None:
            return [self._local_embed(text) for text in texts]

        responses = client.embeddings.create(
            model=self.model,
            input=texts
        )
        return [item.embedding for item in responses.data]



