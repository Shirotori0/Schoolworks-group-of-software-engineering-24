import os
from types import SimpleNamespace

from openai import OpenAI

from .. import config  # noqa: F401

class Agent:
    def __init__(self):
        self.api_key = os.getenv("DEEPSEEK_API_KEY")
        self.client = None
        self.model = "deepseek-v4-pro"

    def _get_client(self):
        if self.client:
            return self.client

        if not self.api_key:
            return None

        self.client = OpenAI(
            api_key=self.api_key,
            base_url="https://api.deepseek.com"
        )
        return self.client

    @staticmethod
    def _mock_response(messages):
        last_content = ""
        for message in reversed(messages):
            if message.get("role") == "user":
                last_content = message.get("content", "")
                break

        preview = last_content.strip().replace("\n", " ")
        if len(preview) > 80:
            preview = f"{preview[:80]}..."

        content = (
            "当前未配置 DEEPSEEK_API_KEY，已使用本地演示模式回复。"
            f"我收到了你的输入：{preview or '空内容'}"
        )
        message = SimpleNamespace(content=content, tool_calls=None)
        choice = SimpleNamespace(message=message)
        return SimpleNamespace(choices=[choice])

    def chat(self, messages, tools, stream=False, reasoning_effort="high"):
        client = self._get_client()
        if client is None:
            return self._mock_response(messages)

        request_args = {
            "model": self.model,
            "messages": messages,
            "stream": stream,
            "reasoning_effort": reasoning_effort,
            "extra_body": {"thinking": {"type": "enabled"}},
        }
        if tools:
            request_args["tools"] = tools

        response = client.chat.completions.create(**request_args)
        return response


