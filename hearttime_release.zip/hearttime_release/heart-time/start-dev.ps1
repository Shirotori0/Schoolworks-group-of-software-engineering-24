$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$backend = Join-Path $root "backend"
$frontend = Join-Path $root "frontend"

Write-Host "Starting backend on http://127.0.0.1:8000"
Start-Process -FilePath "python" `
  -ArgumentList "-m", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", "8000" `
  -WorkingDirectory $backend `
  -WindowStyle Hidden

Start-Sleep -Seconds 2

Write-Host "Starting frontend on http://127.0.0.1:5173"
Start-Process -FilePath "npm.cmd" `
  -ArgumentList "run", "dev", "--", "--host", "127.0.0.1" `
  -WorkingDirectory $frontend `
  -WindowStyle Hidden

Write-Host "Open http://127.0.0.1:5173/"
